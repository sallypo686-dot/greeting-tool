
  # 马年拜年小工具

  This is a code bundle for 马年拜年小工具. The original project is available at https://www.figma.com/design/AClb6tlhvY4rO2SLwE3w0S/%E9%A9%AC%E5%B9%B4%E6%8B%9C%E5%B9%B4%E5%B0%8F%E5%B7%A5%E5%85%B7.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  