import React, { useState } from 'react';
import { Sparkles, Heart, CreditCard, Camera } from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { MemeGenerator } from './components/MemeGenerator';
import { HeartConnection } from './components/HeartConnection';
import { RedPacketCreator } from './components/RedPacketCreator';
import { FloatingBackground } from './components/FloatingBackground';

type Tab = 'meme' | 'heart' | 'packet';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('meme');

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900 pb-20 relative">
      <FloatingBackground />
      
      {/* Header */}
      <header className="bg-[#D32F2F] text-yellow-100 py-6 px-4 shadow-lg sticky top-0 z-50">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-yellow-500 rounded-full text-[#D32F2F]">
              <Sparkles size={24} fill="currentColor" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">金马迎春 2026</h1>
              <p className="text-xs text-yellow-200/80">Spirit of the Horse • Chinese New Year Tool</p>
            </div>
          </div>
          <div className="hidden md:block text-sm font-medium bg-[#B71C1C] px-3 py-1 rounded-full border border-yellow-500/30">
            2026 丙午年
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 relative z-10">
        
        {/* Navigation Tabs */}
        <div className="flex flex-col sm:flex-row gap-2 mb-8 bg-white p-2 rounded-2xl shadow-sm border border-stone-200">
          <TabButton 
            active={activeTab === 'meme'} 
            onClick={() => setActiveTab('meme')}
            icon={<Camera size={20} />}
            title="马气十足表情包"
            desc="Meme Generator"
          />
          <TabButton 
            active={activeTab === 'heart'} 
            onClick={() => setActiveTab('heart')}
            icon={<Heart size={20} />}
            title="双城心连心"
            desc="Heart Connection"
          />
          <TabButton 
            active={activeTab === 'packet'} 
            onClick={() => setActiveTab('packet')}
            icon={<CreditCard size={20} />}
            title="专属红包封面"
            desc="Red Packet Cover"
          />
        </div>

        {/* Feature Container */}
        <div className="bg-white rounded-3xl shadow-xl border border-stone-100 overflow-hidden min-h-[500px]">
          {activeTab === 'meme' && <MemeGenerator />}
          {activeTab === 'heart' && <HeartConnection />}
          {activeTab === 'packet' && <RedPacketCreator />}
        </div>
      </main>

      {/* Footer */}
      <footer className="text-center text-stone-400 text-sm py-8">
        <p>© 2026 Year of the Horse Greetings Tool</p>
      </footer>
    </div>
  );
}

function TabButton({ 
  active, 
  onClick, 
  icon, 
  title, 
  desc 
}: { 
  active: boolean; 
  onClick: () => void; 
  icon: React.ReactNode; 
  title: string; 
  desc: string;
}) {
  return (
    <button
      onClick={onClick}
      className={twMerge(
        "flex-1 flex items-center gap-3 p-4 rounded-xl transition-all duration-200 text-left",
        active 
          ? "bg-red-50 text-[#D32F2F] ring-2 ring-[#D32F2F] ring-offset-0" 
          : "hover:bg-stone-50 text-stone-600"
      )}
    >
      <div className={twMerge(
        "p-2 rounded-lg",
        active ? "bg-[#D32F2F] text-white" : "bg-stone-200 text-stone-500"
      )}>
        {icon}
      </div>
      <div>
        <div className="font-bold text-sm sm:text-base">{title}</div>
        <div className="text-xs opacity-70">{desc}</div>
      </div>
    </button>
  );
}
