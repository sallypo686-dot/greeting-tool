import React, { useState, useRef } from 'react';
import { ImageUploader } from './ImageUploader';
import { Download, RefreshCw, Type, Sticker, Smile, Trash2, ChevronDown, ChevronUp, Palette, Eye, EyeOff } from 'lucide-react';
import { toPng } from 'html-to-image';
import { twMerge } from 'tailwind-merge';
import { motion } from 'motion/react';

// Preset Stickers
const STICKERS = ["🐴", "🧨", "🧧", "💰", "🏮", "🍀", "🐎", "✨"];
const CAPTIONS = ["马到成功", "马上有钱", "恭喜发财", "马年大吉", "Happy CNY", "2026"];

// Style Presets
const FONT_FAMILIES = [
  { name: "黑体", value: "sans-serif" },
  { name: "宋体", value: "serif" },
  { name: "圆体", value: "'Varela Round', sans-serif" },
  { name: "手写", value: "cursive" },
];

const COLORS = [
  { name: "白", value: "#FFFFFF" },
  { name: "金", value: "#FFD700" },
  { name: "红", value: "#D32F2F" },
  { name: "黑", value: "#000000" },
];

interface TextStyle {
  content: string;
  color: string;
  fontSize: number;
  fontFamily: string;
  x: number;
  y: number;
  visible: boolean;
}

export function MemeGenerator() {
  const [image, setImage] = useState<string | null>(null);
  
  const [topText, setTopText] = useState<TextStyle>({
    content: "2026",
    color: "#FFFFFF",
    fontSize: 48,
    fontFamily: "sans-serif",
    x: 100,
    y: 50,
    visible: true
  });
  
  const [bottomText, setBottomText] = useState<TextStyle>({
    content: "马到成功",
    color: "#FFFFFF",
    fontSize: 48,
    fontFamily: "sans-serif",
    x: 100,
    y: 400,
    visible: true
  });

  const [activeTextPanel, setActiveTextPanel] = useState<'top' | 'bottom' | null>('bottom');

  const [selectedStickers, setSelectedStickers] = useState<{id: number, content: string, x: number, y: number}[]>([]);
  const captureRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(false);

  // Helper: Convert File to Base64 to avoid CORS/Fetch issues
  const handleImageUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) setImage(e.target.result as string);
    };
    reader.readAsDataURL(file);
  };

  const addSticker = (content: string) => {
    setSelectedStickers([...selectedStickers, {
      id: Date.now(),
      content,
      x: 200, 
      y: 200
    }]);
  };

  const updateStickerPosition = (id: number, x: number, y: number) => {
    setSelectedStickers(prev => prev.map(s => {
      if (s.id === id) {
        return { ...s, x, y };
      }
      return s;
    }));
  };

  const removeSticker = (id: number) => {
    setSelectedStickers(prev => prev.filter(s => s.id !== id));
  };

  const clearCanvas = () => {
    setImage(null);
    setTopText({ ...topText, content: "2026", x: 100, y: 50, visible: true });
    setBottomText({ ...bottomText, content: "马到成功", x: 100, y: 400, visible: true });
    setSelectedStickers([]);
  };

  const downloadMeme = async () => {
    if (!captureRef.current) return;
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const dataUrl = await toPng(captureRef.current, { 
        cacheBust: true, 
        pixelRatio: 2,
        skipAutoScale: true,
        // No useCORS: true here for Data URLs
        filter: (node) => {
          if (node.tagName === 'BUTTON' && node.getAttribute('title') === 'Remove sticker') {
             return false;
          }
          return true;
        }
      });
      const link = document.createElement('a');
      link.download = `horse-meme-2026-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to download image', err);
      alert("下载图片失败，请重试");
    }
    setLoading(false);
  };

  return (
    <div className="p-6 md:p-8">
      <div className="flex flex-col lg:flex-row gap-8">
        
        {/* Left: Controls */}
        <div className="w-full lg:w-1/3 space-y-6">
          <div>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Smile className="text-red-600" />
              1. 选择图片
            </h2>
            {!image ? (
              <ImageUploader onImageSelect={handleImageUpload} />
            ) : (
              <button 
                onClick={clearCanvas}
                className="w-full py-2 px-4 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg flex items-center justify-center gap-2 text-sm font-medium transition-colors"
              >
                <RefreshCw size={16} /> 更换图片
              </button>
            )}
          </div>

          {image && (
            <>
              <div className="space-y-4">
                 <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Type className="text-red-600" />
                  2. 编辑文字
                </h2>
                
                {/* Top Text Control */}
                <TextControl 
                  label="顶部文字"
                  textState={topText}
                  setTextState={setTopText}
                  isOpen={activeTextPanel === 'top'}
                  onToggle={() => setActiveTextPanel(activeTextPanel === 'top' ? null : 'top')}
                />

                {/* Bottom Text Control */}
                <TextControl 
                  label="底部文字"
                  textState={bottomText}
                  setTextState={setBottomText}
                  isOpen={activeTextPanel === 'bottom'}
                  onToggle={() => setActiveTextPanel(activeTextPanel === 'bottom' ? null : 'bottom')}
                />

                <div className="flex flex-wrap gap-2 mt-2">
                  {CAPTIONS.map(cap => (
                    <button 
                      key={cap}
                      onClick={() => setBottomText(prev => ({ ...prev, content: cap }))}
                      className="text-xs bg-stone-100 hover:bg-stone-200 px-2 py-1 rounded-md transition-colors"
                    >
                      {cap}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Sticker className="text-red-600" />
                  3. 装饰贴纸
                </h2>
                <div className="grid grid-cols-4 gap-2">
                  {STICKERS.map(s => (
                    <button 
                      key={s} 
                      onClick={() => addSticker(s)}
                      className="text-2xl p-2 bg-stone-50 hover:bg-yellow-100 rounded-lg border border-stone-200 transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-stone-400 mt-2">提示：文字和贴纸均可自由拖动</p>
              </div>

              <button 
                onClick={downloadMeme}
                disabled={loading}
                className="w-full py-4 bg-[#D32F2F] hover:bg-[#B71C1C] text-white rounded-xl shadow-lg shadow-red-200 flex items-center justify-center gap-2 font-bold text-lg transition-all transform active:scale-95"
              >
                {loading ? '生成中...' : '下载表情包'} <Download size={20} />
              </button>
            </>
          )}
        </div>

        {/* Right: Preview Canvas */}
        <div className="w-full lg:w-2/3 bg-stone-100 rounded-2xl p-4 md:p-8 flex items-center justify-center min-h-[400px]">
          {image ? (
            <div 
              ref={captureRef}
              className="relative overflow-hidden shadow-2xl bg-white max-w-full"
              style={{ width: '500px', height: '500px' }}
            >
              {/* Background Image */}
              <img 
                src={image} 
                alt="Meme Base" 
                className="w-full h-full object-cover pointer-events-none" 
              />
              
              {/* Overlay Text - Top */}
              {topText.visible && (
                <motion.div 
                  className="absolute cursor-move whitespace-nowrap px-2 border border-transparent hover:border-dashed hover:border-white/50 rounded"
                  style={{ 
                    left: topText.x,
                    top: topText.y,
                    touchAction: "none"
                  }}
                  drag
                  dragMomentum={false}
                  dragElastic={0}
                  dragConstraints={captureRef}
                  onDragEnd={(e, info) => {
                    // Update state with the delta
                    setTopText(prev => ({ ...prev, x: prev.x + info.offset.x, y: prev.y + info.offset.y }));
                  }}
                >
                  <span 
                    className="font-black uppercase tracking-wider block leading-tight select-none"
                    style={{ 
                      fontFamily: topText.fontFamily,
                      color: topText.color,
                      fontSize: `${topText.fontSize}px`,
                      textShadow: '2px 2px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000' 
                    }}
                  >
                    {topText.content}
                  </span>
                </motion.div>
              )}
              
              {/* Overlay Text - Bottom */}
              {bottomText.visible && (
                <motion.div 
                  className="absolute cursor-move whitespace-nowrap px-2 border border-transparent hover:border-dashed hover:border-white/50 rounded"
                  style={{ 
                    left: bottomText.x,
                    top: bottomText.y,
                    touchAction: "none"
                  }}
                  drag
                  dragMomentum={false}
                  dragElastic={0}
                  dragConstraints={captureRef}
                  onDragEnd={(e, info) => {
                    setBottomText(prev => ({ ...prev, x: prev.x + info.offset.x, y: prev.y + info.offset.y }));
                  }}
                >
                  <span 
                    className="font-black uppercase tracking-wider block leading-tight select-none"
                    style={{ 
                      fontFamily: bottomText.fontFamily,
                      color: bottomText.color,
                      fontSize: `${bottomText.fontSize}px`,
                      textShadow: '2px 2px 0 #000, -1px -1px 0 #000, 1px -1px 0 #000, -1px 1px 0 #000, 1px 1px 0 #000' 
                    }}
                  >
                    {bottomText.content}
                  </span>
                </motion.div>
              )}

              {/* Stickers */}
              {selectedStickers.map((sticker) => (
                <motion.div
                  key={sticker.id}
                  className="absolute cursor-move text-6xl select-none flex flex-col items-center group z-10"
                  style={{ 
                    left: sticker.x, 
                    top: sticker.y,
                    touchAction: "none" 
                  }}
                  drag
                  dragMomentum={false}
                  dragElastic={0}
                  dragConstraints={captureRef}
                  onDragEnd={(event, info) => {
                    updateStickerPosition(sticker.id, sticker.x + info.offset.x, sticker.y + info.offset.y);
                  }}
                  whileHover={{ scale: 1.1, cursor: "grab" }}
                  whileTap={{ scale: 0.95, cursor: "grabbing" }}
                >
                  {sticker.content}
                  
                  {/* Delete Button (Visible on Hover/Tap) */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSticker(sticker.id);
                    }}
                    className="absolute -top-4 -right-4 bg-stone-900/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity z-20"
                    title="Remove sticker"
                    onPointerDownCapture={(e) => e.stopPropagation()} 
                  >
                    <Trash2 size={14} />
                  </button>
                </motion.div>
              ))}
              
              {/* Watermark */}
              <div className="absolute bottom-1 right-2 text-[10px] text-white/50 font-mono pointer-events-none">
                Made with Spirit of Horse 2026
              </div>
            </div>
          ) : (
            <div className="text-center text-stone-400">
              <div className="inline-block p-4 rounded-full bg-stone-200 mb-4">
                <Smile size={48} />
              </div>
              <p>请先上传一张图片开始制作</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function TextControl({ 
  label, 
  textState, 
  setTextState, 
  isOpen, 
  onToggle 
}: { 
  label: string; 
  textState: TextStyle; 
  setTextState: (s: TextStyle) => void;
  isOpen: boolean;
  onToggle: () => void;
}) {
  return (
    <div className="border border-stone-200 rounded-xl bg-white overflow-hidden shadow-sm">
      <div className="flex items-center justify-between bg-stone-50 border-b border-stone-100 pr-2">
        <button 
          onClick={onToggle}
          className="flex-1 flex items-center justify-between p-3 hover:bg-stone-100 transition-colors text-sm font-bold text-stone-700 text-left"
        >
          <span>{label}</span>
          {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        <button
          onClick={(e) => {
             e.stopPropagation();
             setTextState({ ...textState, visible: !textState.visible });
          }}
          className={twMerge(
            "p-1.5 rounded-md transition-colors",
            textState.visible ? "text-stone-500 hover:text-stone-800 hover:bg-stone-200" : "text-stone-300 hover:text-stone-500"
          )}
          title={textState.visible ? "Hide Text" : "Show Text"}
        >
          {textState.visible ? <Eye size={18} /> : <EyeOff size={18} />}
        </button>
      </div>
      
      {isOpen && (
        <div className={twMerge("p-4 space-y-4 animate-in slide-in-from-top-2 duration-200", !textState.visible && "opacity-50 pointer-events-none grayscale")}>
          {/* Text Input */}
          <input 
            type="text" 
            value={textState.content} 
            onChange={(e) => setTextState({ ...textState, content: e.target.value })}
            className="w-full p-2 border border-stone-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
            placeholder="输入文字..."
          />
          
          {/* Controls Grid */}
          <div className="grid grid-cols-2 gap-3">
             {/* Font Size */}
             <div className="col-span-2 space-y-1">
               <div className="flex justify-between text-xs text-stone-500">
                  <span>大小</span>
                  <span>{textState.fontSize}px</span>
               </div>
               <input 
                  type="range" 
                  min="20" 
                  max="120" 
                  value={textState.fontSize} 
                  onChange={(e) => setTextState({ ...textState, fontSize: parseInt(e.target.value) })}
                  className="w-full accent-red-600 h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer"
               />
             </div>

             {/* Font Family */}
             <div className="space-y-1">
                <label className="text-xs text-stone-500">字体</label>
                <select 
                  value={textState.fontFamily}
                  onChange={(e) => setTextState({ ...textState, fontFamily: e.target.value })}
                  className="w-full p-1.5 text-sm border border-stone-300 rounded bg-white"
                >
                  {FONT_FAMILIES.map(f => (
                    <option key={f.value} value={f.value}>{f.name}</option>
                  ))}
                </select>
             </div>

             {/* Color */}
             <div className="space-y-1">
                <label className="text-xs text-stone-500">颜色</label>
                <div className="flex gap-2">
                  {COLORS.map(c => (
                    <button
                      key={c.value}
                      onClick={() => setTextState({ ...textState, color: c.value })}
                      className={twMerge(
                        "w-6 h-6 rounded-full border border-stone-300 shadow-sm",
                        textState.color === c.value ? "ring-2 ring-blue-500 ring-offset-1" : ""
                      )}
                      style={{ backgroundColor: c.value }}
                      title={c.name}
                    />
                  ))}
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
