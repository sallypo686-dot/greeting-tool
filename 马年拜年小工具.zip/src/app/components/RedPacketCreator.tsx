import React, { useState, useRef } from 'react';
import { ImageUploader } from './ImageUploader';
import { Download, RefreshCw, User, Settings2 } from 'lucide-react';
import { toPng } from 'html-to-image';
import { clsx } from 'clsx';

export function RedPacketCreator() {
  const [bgImage, setBgImage] = useState<string | null>(null);
  const [blessing, setBlessing] = useState("大吉大利");
  const [userName, setUserName] = useState("我的名字");
  const [showUI, setShowUI] = useState(true); // Toggle to download clean image or with UI
  const captureRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(false);

  // Helper: Convert File to Base64 to avoid CORS/Fetch issues
  const handleImageSelect = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) setBgImage(e.target.result as string);
    };
    reader.readAsDataURL(file);
  };

  const downloadCover = async () => {
    if (!captureRef.current) return;
    setLoading(true);
    try {
      // Delay to ensure rendering is settled
      await new Promise(resolve => setTimeout(resolve, 300));

      const dataUrl = await toPng(captureRef.current, { 
        cacheBust: true, 
        pixelRatio: 2,
        skipAutoScale: true,
        backgroundColor: '#C93830' // Force red background if transparency issues
      });
      const link = document.createElement('a');
      link.download = `red-packet-2026-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error(err);
      alert("保存失败，请重试");
    }
    setLoading(false);
  };

  return (
    <div className="p-6 md:p-8 flex flex-col lg:flex-row gap-8">
      {/* Sidebar Controls */}
      <div className="w-full lg:w-1/3 space-y-6">
        <div>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-stone-800">
             <div className="w-6 h-6 bg-red-500 rounded text-white flex items-center justify-center text-xs">￥</div>
             制作红包封面
          </h2>
          {!bgImage ? (
             <ImageUploader onImageSelect={handleImageSelect} label="上传封面背景图" />
          ) : (
            <button 
              onClick={() => setBgImage(null)}
              className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded-lg flex items-center justify-center gap-2 text-sm transition-colors"
            >
              <RefreshCw size={16} /> 更换图片
            </button>
          )}
        </div>

        {bgImage && (
          <div className="space-y-4 animate-in fade-in slide-in-from-left-4">
             <div className="p-4 bg-stone-50 rounded-xl space-y-3 border border-stone-200">
                <div className="flex items-center gap-2 mb-2 text-stone-500 text-sm font-semibold">
                  <Settings2 size={16} /> 配置信息
                </div>
                <div>
                  <label className="text-xs text-stone-400">用户名</label>
                  <input 
                    value={userName} 
                    onChange={(e) => setUserName(e.target.value)}
                    className="w-full bg-white border border-stone-300 rounded px-2 py-1 text-sm outline-none focus:border-red-500"
                  />
                </div>
                <div>
                  <label className="text-xs text-stone-400">祝福语</label>
                  <input 
                    value={blessing} 
                    onChange={(e) => setBlessing(e.target.value)}
                    className="w-full bg-white border border-stone-300 rounded px-2 py-1 text-sm outline-none focus:border-red-500"
                  />
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <input 
                    type="checkbox" 
                    id="showUI" 
                    checked={showUI} 
                    onChange={(e) => setShowUI(e.target.checked)}
                    className="rounded text-red-600 focus:ring-red-500"
                  />
                  <label htmlFor="showUI" className="text-sm text-stone-600">下载时包含UI界面</label>
                </div>
             </div>

             <button 
                onClick={downloadCover}
                disabled={loading}
                className="w-full py-3 bg-yellow-500 hover:bg-yellow-600 text-red-900 rounded-xl shadow-lg shadow-yellow-200 flex items-center justify-center gap-2 font-bold transition-all"
              >
                {loading ? '生成中...' : '保存图片'} <Download size={18} />
              </button>
          </div>
        )}
      </div>

      {/* Preview Area - Mobile Aspect Ratio */}
      <div className="w-full lg:w-2/3 bg-stone-100 rounded-2xl p-4 flex items-center justify-center">
         {bgImage ? (
           <div 
             ref={captureRef}
             className="relative w-[320px] h-[568px] overflow-hidden shadow-2xl bg-[#C93830]"
             style={{ borderRadius: '12px' }}
           >
             {/* The User Image (Cover) */}
             <div className="absolute top-0 left-0 w-full h-[75%] overflow-hidden">
                <div className="w-full h-full bg-black">
                   <img src={bgImage} className="w-full h-full object-cover opacity-90" alt="Cover" />
                </div>
                {/* Curved bottom edge of image container - WeChat style often has a curve or just straight. 
                    Let's add a subtle gradient at bottom for blend */}
                <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-[#C93830] to-transparent" />
             </div>

             {/* WeChat UI Layer */}
             <div className={clsx("absolute inset-0 flex flex-col items-center pt-16 transition-opacity", showUI ? "opacity-100" : "opacity-0")}>
                
                {/* User Info */}
                <div className="flex items-center gap-2 text-[#F3D7A4] mb-4">
                  <div className="w-8 h-8 rounded-full bg-stone-300 flex items-center justify-center overflow-hidden border border-[#F3D7A4]/30">
                     <User size={20} className="text-stone-500" />
                  </div>
                  <span className="font-medium text-lg drop-shadow-md">{userName}</span>
                </div>

                {/* Blessing */}
                <h1 className="text-[#F3D7A4] text-2xl font-bold tracking-wide drop-shadow-md mb-8">
                  {blessing}
                </h1>

                {/* Open Button (Kai) */}
                <div className="mt-auto mb-20 relative group cursor-pointer">
                   <div className="w-24 h-24 rounded-full bg-[#E8C27D] flex items-center justify-center shadow-lg border-4 border-[#F3D7A4] z-10 relative transform transition-transform group-hover:scale-105">
                      <span className="text-[#C93830] text-4xl font-serif font-bold">開</span>
                   </div>
                   {/* Glow effect */}
                   <div className="absolute inset-0 bg-yellow-400 rounded-full blur-xl opacity-20 group-hover:opacity-40 transition-opacity" />
                </div>

                <div className="absolute bottom-4 text-[#F3D7A4]/40 text-xs">
                   微信红包
                </div>
             </div>
           </div>
         ) : (
            <div className="text-stone-300 flex flex-col items-center">
               <div className="w-[320px] h-[568px] border-4 border-dashed border-stone-200 rounded-3xl flex items-center justify-center">
                 <span className="text-sm">预览区域</span>
               </div>
            </div>
         )}
      </div>
    </div>
  );
}
