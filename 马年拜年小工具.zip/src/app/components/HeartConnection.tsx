import React, { useState, useRef } from 'react';
import { ImageUploader } from './ImageUploader';
import { Download, Heart, MapPin, RefreshCw, Type, Sticker, ChevronDown, ChevronUp, Eye, EyeOff, Trash2 } from 'lucide-react';
import { toPng } from 'html-to-image';
import { twMerge } from 'tailwind-merge';
import { motion } from 'motion/react';

// --- Shared Types & Constants ---
const STICKERS = ["🐴", "✈️", "🏠", "❤️", "📍", "🎫", "🌏", "✨"];
const FONT_FAMILIES = [
  { name: "黑体", value: "sans-serif" },
  { name: "宋体", value: "serif" },
  { name: "圆体", value: "'Varela Round', sans-serif" },
  { name: "手写", value: "cursive" },
];
const COLORS = [
  { name: "白", value: "#FFFFFF" },
  { name: "金", value: "#FFD700" },
  { name: "红", value: "#D32F2F" },
  { name: "黑", value: "#000000" },
];

interface TextStyle {
  content: string;
  color: string;
  fontSize: number;
  fontFamily: string;
  x: number;
  y: number;
  visible: boolean;
  align: 'left' | 'center' | 'right'; 
}

interface StickerItem {
  id: number;
  content: string;
  x: number;
  y: number;
}

// --- Main Component ---
export function HeartConnection() {
  const [cityImage, setCityImage] = useState<string | null>(null);
  const [hometownImage, setHometownImage] = useState<string | null>(null);
  
  // Adjusted Initial State to match the provided design:
  // Positioned lower (y=380), tighter to center line, larger font
  const [textItems, setTextItems] = useState<TextStyle[]>([
    { content: "广州", color: "#FFFFFF", fontSize: 48, fontFamily: "sans-serif", x: 245, y: 380, visible: true, align: 'right' },
    { content: "武汉", color: "#FFFFFF", fontSize: 48, fontFamily: "sans-serif", x: 255, y: 380, visible: true, align: 'left' }
  ]);
  const [activeTextPanel, setActiveTextPanel] = useState<number | null>(null);

  const [stickers, setStickers] = useState<StickerItem[]>([]);
  const captureRef = useRef<HTMLDivElement>(null);
  const [loading, setLoading] = useState(false);

  // Helper: Convert File to Base64 to avoid CORS/Fetch issues
  const handleImageSelect = (file: File, setter: (val: string) => void) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) setter(e.target.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleDownload = async () => {
    if (!captureRef.current) return;
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500)); 
      
      const dataUrl = await toPng(captureRef.current, { 
        cacheBust: true, 
        pixelRatio: 2,
        skipAutoScale: true,
        backgroundColor: 'transparent',
        filter: (node) => {
           if (node.tagName === 'BUTTON') return false;
           return true;
        }
      });
      
      const link = document.createElement('a');
      link.download = `heart-connect-2026-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err: any) {
      console.error("Download failed:", err);
      alert(`下载失败: ${err.message || "请重试"}`);
    }
    setLoading(false);
  };

  const updateTextItem = (index: number, newState: Partial<TextStyle>) => {
    const newItems = [...textItems];
    newItems[index] = { ...newItems[index], ...newState };
    setTextItems(newItems);
  };

  const addSticker = (content: string) => {
    setStickers([...stickers, { id: Date.now(), content, x: 250, y: 250 }]);
  };

  const updateStickerPos = (id: number, x: number, y: number) => {
    setStickers(prev => prev.map(s => s.id === id ? { ...s, x, y } : s));
  };

  const removeSticker = (id: number) => {
    setStickers(prev => prev.filter(s => s.id !== id));
  };

  const isReady = cityImage && hometownImage;

  return (
    <div className="p-6 md:p-8 flex flex-col lg:flex-row gap-8">
      {/* Left: Controls */}
      <div className="w-full lg:w-1/3 space-y-6">
        <div className="space-y-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <MapPin className="text-red-600" /> 1. 上传照片
          </h2>
          
          <div className="grid grid-cols-2 gap-4">
             <div className="space-y-2">
                <label className="text-xs font-bold text-stone-500">左: 当前城市</label>
                {!cityImage ? (
                  <ImageUploader onImageSelect={(f) => handleImageSelect(f, setCityImage)} compact label="上传" className="h-32 min-h-0" />
                ) : (
                  <div className="relative h-32 rounded-lg overflow-hidden group border border-stone-200">
                    <img src={cityImage} className="w-full h-full object-cover" alt="City" />
                    <button 
                      onClick={() => setCityImage(null)} 
                      className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center text-white"
                    >
                      <RefreshCw size={20} />
                    </button>
                  </div>
                )}
             </div>
             <div className="space-y-2">
                <label className="text-xs font-bold text-stone-500">右: 家乡</label>
                {!hometownImage ? (
                  <ImageUploader onImageSelect={(f) => handleImageSelect(f, setHometownImage)} compact label="上传" className="h-32 min-h-0" />
                ) : (
                  <div className="relative h-32 rounded-lg overflow-hidden group border border-stone-200">
                    <img src={hometownImage} className="w-full h-full object-cover" alt="Hometown" />
                    <button 
                      onClick={() => setHometownImage(null)} 
                      className="absolute inset-0 bg-black/50 hidden group-hover:flex items-center justify-center text-white"
                    >
                      <RefreshCw size={20} />
                    </button>
                  </div>
                )}
             </div>
          </div>
        </div>

        {isReady && (
          <>
            <div className="space-y-2">
               <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                  <Type className="text-red-600" /> 2. 编辑文字
               </h2>
               {textItems.map((item, idx) => (
                 <TextControl 
                    key={idx}
                    label={`文字 ${idx + 1} (${idx === 0 ? '左侧' : '右侧'})`}
                    textState={item}
                    setTextState={(s: any) => updateTextItem(idx, s)}
                    isOpen={activeTextPanel === idx}
                    onToggle={() => setActiveTextPanel(activeTextPanel === idx ? null : idx)}
                 />
               ))}
            </div>

            <div>
              <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
                <Sticker className="text-red-600" /> 3. 装饰贴纸
              </h2>
              <div className="grid grid-cols-4 gap-2">
                {STICKERS.map(s => (
                  <button 
                    key={s} 
                    onClick={() => addSticker(s)}
                    className="text-2xl p-2 bg-stone-50 hover:bg-yellow-100 rounded-lg border border-stone-200 transition-colors"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <button 
              onClick={handleDownload}
              disabled={loading}
              className="w-full py-4 bg-red-600 hover:bg-red-700 text-white rounded-xl shadow-lg flex items-center justify-center gap-2 font-bold transition-all transform active:scale-95"
            >
              {loading ? '处理中...' : '下载爱心海报'} <Download size={20} />
            </button>
          </>
        )}
      </div>

      {/* Right: Preview Canvas */}
      <div className="w-full lg:w-2/3 bg-stone-100 rounded-2xl p-4 md:p-8 flex items-center justify-center min-h-[500px]">
         {isReady ? (
           <div 
             ref={captureRef}
             className="relative w-[500px] h-[500px] bg-transparent overflow-hidden select-none" 
           >
             {/* SVG Defs for ClipPath */}
             <svg width="0" height="0" className="absolute" style={{ position: 'absolute', top: 0, left: 0, pointerEvents: 'none' }}>
               <defs>
                 <clipPath id="fullHeartClip" clipPathUnits="objectBoundingBox">
                   <path d="M0.5,0.92 C0.5,0.92 0.1,0.65 0.02,0.4 C-0.05,0.2 0.15,0.02 0.35,0.02 C0.45,0.02 0.5,0.1 0.5,0.1 C0.5,0.1 0.55,0.02 0.65,0.02 C0.85,0.02 1.05,0.2 0.98,0.4 C0.9,0.65 0.5,0.92 0.5,0.92 Z" />
                 </clipPath>
               </defs>
             </svg>

             {/* The Heart Container - Clipped */}
             <div 
               className="absolute inset-4 z-0 bg-red-50 shadow-2xl"
               style={{ 
                  clipPath: 'url(#fullHeartClip)',
                  WebkitClipPath: 'url(#fullHeartClip)' 
               }}
             >
                <div className="absolute inset-0 flex">
                   {/* Left Image Area - No Drag */}
                   <div className="w-1/2 h-full relative border-r-2 border-white/30 overflow-hidden bg-stone-200">
                      <img 
                        src={cityImage} 
                        className="w-full h-full object-cover"
                        alt="City"
                      />
                   </div>
                   {/* Right Image Area - No Drag */}
                   <div className="w-1/2 h-full relative overflow-hidden bg-stone-200">
                      <img 
                        src={hometownImage} 
                        className="w-full h-full object-cover"
                        alt="Hometown"
                      />
                   </div>
                </div>
                {/* Gloss overlay */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent pointer-events-none" />
             </div>

             {/* Draggable Text Items */}
             {textItems.map((item, idx) => item.visible && (
                <motion.div 
                  key={`text-${idx}`}
                  className="absolute cursor-move px-2 whitespace-nowrap z-10"
                  style={{ 
                    left: item.x,
                    top: item.y,
                    // If align is right, we translate -100% to make the 'left' prop the right edge
                    translateX: item.align === 'right' ? '-100%' : '0%',
                    touchAction: "none"
                  }}
                  drag
                  dragMomentum={false}
                  dragElastic={0}
                  dragConstraints={captureRef}
                  onDragEnd={(e, info) => {
                    updateTextItem(idx, { x: item.x + info.offset.x, y: item.y + info.offset.y });
                  }}
                >
                  <span 
                    className="font-black uppercase tracking-wider block leading-tight select-none drop-shadow-md"
                    style={{ 
                      fontFamily: item.fontFamily,
                      color: item.color,
                      fontSize: `${item.fontSize}px`,
                      textAlign: item.align, // visual text alignment
                      textShadow: '1px 1px 3px rgba(0,0,0,0.6)' 
                    }}
                  >
                    {item.content}
                  </span>
                </motion.div>
             ))}

             {/* Stickers */}
             {stickers.map((sticker) => (
                <motion.div
                  key={`sticker-${sticker.id}`}
                  className="absolute cursor-move text-6xl select-none flex flex-col items-center group z-20"
                  style={{ 
                    left: sticker.x, 
                    top: sticker.y,
                    translateX: '-50%',
                    translateY: '-50%',
                    touchAction: "none"
                  }}
                  drag
                  dragMomentum={false}
                  dragElastic={0}
                  dragConstraints={captureRef}
                  onDragEnd={(event, info) => {
                    updateStickerPos(sticker.id, sticker.x + info.offset.x, sticker.y + info.offset.y);
                  }}
                  whileHover={{ scale: 1.1, cursor: "grab" }}
                  whileTap={{ scale: 0.95, cursor: "grabbing" }}
                >
                  <div style={{ filter: 'drop-shadow(2px 4px 6px rgba(0,0,0,0.2))' }}>
                     {sticker.content}
                  </div>
                  
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeSticker(sticker.id);
                    }}
                    className="absolute -top-4 -right-4 bg-stone-900/80 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    onPointerDownCapture={(e) => e.stopPropagation()}
                  >
                    <Trash2 size={14} />
                  </button>
                </motion.div>
              ))}

              <div className="absolute bottom-2 w-full text-center pointer-events-none opacity-50">
                 <p className="text-[10px] text-stone-400">Spirit of the Horse 2026 • Heart Connection</p>
              </div>

           </div>
         ) : (
            <div className="text-center py-10">
               <div className="w-24 h-24 bg-stone-200 rounded-full mx-auto mb-4 flex items-center justify-center text-stone-400">
                  <Heart size={48} />
               </div>
               <p className="text-stone-500 font-medium">请先上传“城市”和“家乡”两张照片</p>
            </div>
         )}
      </div>
    </div>
  );
}

// Reuse TextControl (Identical)
function TextControl({ label, textState, setTextState, isOpen, onToggle }: any) {
   return (
    <div className="border border-stone-200 rounded-xl bg-white overflow-hidden shadow-sm">
      <div className="flex items-center justify-between bg-stone-50 border-b border-stone-100 pr-2">
        <button onClick={onToggle} className="flex-1 flex items-center justify-between p-3 hover:bg-stone-100 transition-colors text-sm font-bold text-stone-700 text-left">
          <span>{label}</span>
          {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
        <button onClick={(e) => { e.stopPropagation(); setTextState({ visible: !textState.visible }); }} className={twMerge("p-1.5 rounded-md transition-colors", textState.visible ? "text-stone-500" : "text-stone-300")}>
          {textState.visible ? <Eye size={18} /> : <EyeOff size={18} />}
        </button>
      </div>
      {isOpen && (
        <div className={twMerge("p-4 space-y-4", !textState.visible && "opacity-50 pointer-events-none grayscale")}>
          <input type="text" value={textState.content} onChange={(e) => setTextState({ content: e.target.value })} className="w-full p-2 border border-stone-300 rounded-lg outline-none" />
          <div className="grid grid-cols-2 gap-3">
             <div className="col-span-2 space-y-1">
               <div className="flex justify-between text-xs text-stone-500"><span>大小</span><span>{textState.fontSize}px</span></div>
               <input type="range" min="12" max="80" value={textState.fontSize} onChange={(e) => setTextState({ fontSize: parseInt(e.target.value) })} className="w-full accent-red-600 h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer" />
             </div>
             <div className="space-y-1">
                <label className="text-xs text-stone-500">字体</label>
                <select value={textState.fontFamily} onChange={(e) => setTextState({ fontFamily: e.target.value })} className="w-full p-1.5 text-sm border border-stone-300 rounded bg-white">
                  {FONT_FAMILIES.map(f => <option key={f.value} value={f.value}>{f.name}</option>)}
                </select>
             </div>
             <div className="space-y-1">
                <label className="text-xs text-stone-500">颜色</label>
                <div className="flex gap-2">
                  {COLORS.map(c => <button key={c.value} onClick={() => setTextState({ color: c.value })} className={twMerge("w-6 h-6 rounded-full border border-stone-300", textState.color === c.value ? "ring-2 ring-blue-500" : "")} style={{ backgroundColor: c.value }} />)}
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
}
