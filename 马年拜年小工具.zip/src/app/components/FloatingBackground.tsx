import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';

const EMOJIS = ["🐴", "🐎", "🧨", "🧧", "💰", "🏮", "✨", "🍊", "🐎"];

interface Particle {
  id: number;
  emoji: string;
  left: string;
  size: number;
  duration: number;
  delay: number;
}

export function FloatingBackground() {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    // Generate particles on client side to avoid hydration mismatch
    const particleCount = 20;
    const newParticles: Particle[] = [];

    for (let i = 0; i < particleCount; i++) {
      newParticles.push({
        id: i,
        emoji: EMOJIS[Math.floor(Math.random() * EMOJIS.length)],
        left: `${Math.random() * 100}%`,
        size: Math.random() * 20 + 20, // 20px - 40px
        duration: Math.random() * 20 + 10, // 10s - 30s
        delay: Math.random() * 10 * -1, // Negative delay to start mid-animation
      });
    }

    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {particles.map((particle) => (
        <motion.div
          key={particle.id}
          className="absolute"
          style={{
            left: particle.left,
            fontSize: `${particle.size}px`,
            opacity: 0.3, // Subtle opacity
          }}
          initial={{ y: "110vh", rotate: 0 }}
          animate={{ 
            y: "-10vh",
            rotate: 360,
          }}
          transition={{
            duration: particle.duration,
            ease: "linear",
            repeat: Infinity,
            delay: particle.delay, // Use negative delay if supported or handle manually
          }}
        >
          {particle.emoji}
        </motion.div>
      ))}
    </div>
  );
}
