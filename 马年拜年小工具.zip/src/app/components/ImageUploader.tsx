import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { twMerge } from 'tailwind-merge';

interface ImageUploaderProps {
  onImageSelect: (file: File) => void;
  label?: string;
  className?: string;
  compact?: boolean;
}

export function ImageUploader({ onImageSelect, label = "Upload Image", className, compact = false }: ImageUploaderProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles && acceptedFiles.length > 0) {
      onImageSelect(acceptedFiles[0]);
    }
  }, [onImageSelect]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.webp']
    },
    multiple: false
  });

  return (
    <div
      {...getRootProps()}
      className={twMerge(
        "border-2 border-dashed rounded-xl transition-colors cursor-pointer flex flex-col items-center justify-center text-center",
        isDragActive ? "border-red-500 bg-red-50" : "border-stone-300 hover:border-red-400 hover:bg-stone-50",
        compact ? "p-4 min-h-[120px]" : "p-10 min-h-[200px]",
        className
      )}
    >
      <input {...getInputProps()} />
      <div className="bg-stone-100 p-3 rounded-full mb-3 text-stone-500">
        {compact ? <Upload size={20} /> : <ImageIcon size={32} />}
      </div>
      <p className="font-medium text-stone-700">{label}</p>
      {!compact && (
        <p className="text-sm text-stone-400 mt-1">
          {isDragActive ? "Drop it here!" : "Drag & drop or click to select"}
        </p>
      )}
    </div>
  );
}
